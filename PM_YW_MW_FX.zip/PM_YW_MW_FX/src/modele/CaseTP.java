package modele;

public class CaseTP extends Case {
}
