package modele;

public class CaseVide extends Case
{
}
