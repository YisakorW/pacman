package modele;

public class CaseMur extends Case {
}
