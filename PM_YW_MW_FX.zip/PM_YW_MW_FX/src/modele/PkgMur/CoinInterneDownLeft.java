package modele.PkgMur;

import modele.CaseMur;

public class CoinInterneDownLeft extends CaseMur
{
}
