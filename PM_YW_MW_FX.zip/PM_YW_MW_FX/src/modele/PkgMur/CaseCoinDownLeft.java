package modele.PkgMur;

import modele.CaseMur;

public class CaseCoinDownLeft extends CaseMur
{
}
