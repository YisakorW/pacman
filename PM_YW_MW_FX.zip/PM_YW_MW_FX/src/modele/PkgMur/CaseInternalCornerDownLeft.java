package modele.PkgMur;

import modele.CaseMur;

public class CaseInternalCornerDownLeft extends CaseMur
{
}
