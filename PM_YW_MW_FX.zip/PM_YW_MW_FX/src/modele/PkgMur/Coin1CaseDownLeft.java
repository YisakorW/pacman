package modele.PkgMur;

import modele.CaseMur;

public class Coin1CaseDownLeft extends CaseMur
{
}
