package modele.PkgMur;

import modele.CaseMur;

public class CaseCoinUpLeft extends CaseMur
{
}
