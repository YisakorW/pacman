package modele.PkgMur;

import modele.CaseMur;

public class CaseCoinUpRight extends CaseMur
{
}
