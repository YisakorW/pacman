package modele.PkgMur;

import modele.CaseMur;

public class Case1PleinHorizontal extends CaseMur
{

}
