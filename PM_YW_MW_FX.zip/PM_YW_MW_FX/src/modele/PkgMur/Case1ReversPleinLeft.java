package modele.PkgMur;

import modele.CaseMur;

public class Case1ReversPleinLeft extends CaseMur
{
}
