package modele.PkgMur;

import modele.CaseMur;

public class Coin1CaseUpLeft extends CaseMur
{
}
