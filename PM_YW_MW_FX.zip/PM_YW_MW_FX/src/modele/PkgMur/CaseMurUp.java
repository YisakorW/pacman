package modele.PkgMur;

import modele.CaseMur;

public class CaseMurUp extends CaseMur
{
}
