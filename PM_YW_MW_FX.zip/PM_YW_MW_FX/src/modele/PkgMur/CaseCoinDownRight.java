package modele.PkgMur;

import modele.CaseMur;

public class CaseCoinDownRight extends CaseMur
{
}
