package modele.PkgMur;

import modele.CaseMur;

public class Case1PleinVertical extends CaseMur
{
}
