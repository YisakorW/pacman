package modele.PkgMur;

import modele.CaseMur;

public class Coin1CaseDownRight extends CaseMur
{
}
