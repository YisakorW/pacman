package modele.PkgMur;

import modele.CaseMur;

public class Case1ReversPleinRight extends CaseMur
{
}
