package modele.PkgMur;

import modele.CaseMur;

public class CaseMurLeft extends CaseMur
{
}
