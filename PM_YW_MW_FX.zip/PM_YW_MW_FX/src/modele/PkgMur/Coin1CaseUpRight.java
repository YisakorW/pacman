package modele.PkgMur;

import modele.CaseMur;

public class Coin1CaseUpRight extends CaseMur
{
}
