package modele.PkgMur;

import modele.CaseMur;

public class CaseInternalCornerUpLeft extends CaseMur
{
}
