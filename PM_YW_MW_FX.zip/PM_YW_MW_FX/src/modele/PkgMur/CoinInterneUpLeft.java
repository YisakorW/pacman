package modele.PkgMur;

import modele.CaseMur;

public class CoinInterneUpLeft extends CaseMur
{
}
