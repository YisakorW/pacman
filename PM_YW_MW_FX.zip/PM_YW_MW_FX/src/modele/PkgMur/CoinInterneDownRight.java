package modele.PkgMur;

import modele.CaseMur;

public class CoinInterneDownRight extends CaseMur
{
}
