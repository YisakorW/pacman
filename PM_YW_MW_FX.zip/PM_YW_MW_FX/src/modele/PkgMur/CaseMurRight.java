package modele.PkgMur;

import modele.CaseMur;

public class CaseMurRight extends CaseMur
{
}
