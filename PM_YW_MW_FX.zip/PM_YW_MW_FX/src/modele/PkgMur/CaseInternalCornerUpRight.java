package modele.PkgMur;

import modele.CaseMur;

public class CaseInternalCornerUpRight extends CaseMur
{
}
