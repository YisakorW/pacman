package modele;

public class CaseSuperGomme extends Case
{
}
