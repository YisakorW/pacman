package modele;

public class CaseGomme extends Case
{
}
