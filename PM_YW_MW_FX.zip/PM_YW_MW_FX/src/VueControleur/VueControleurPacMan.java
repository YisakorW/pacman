package VueControleur;

import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import modele.Direction;
import modele.Fantome;
import modele.Jeu;
import modele.Pacman;
//import modele.Mur;
import modele.*;
import modele.PkgMur.*;


/** Cette classe a deux fonctions :
 *  (1) Vue : proposer une représentation graphique de l'application (cases graphiques, etc.)
 *  (2) Controleur : écouter les évènements clavier et déclencher le traitement adapté sur le modèle (flèches direction Pacman, etc.))
 *
 * @author freder
 */
public class VueControleurPacMan extends JFrame implements Observer {

    private Jeu jeu; // référence sur une classe de modèle : permet d'accéder aux données du modèle pour le rafraichissement, permet de communiquer les actions clavier (ou souris)

    private int sizeX; // taille de la grille affichée
    private int sizeY;

    private ImageIcon icoPacMan; // icones affichées dans la grille
    private ImageIcon icoPacManG;
    private ImageIcon icoPacManH;
    private ImageIcon icoPacManB;
    
    
    private ImageIcon icoFantome;
    private ImageIcon icoFantomeMort;
    
    private ImageIcon icoCouloir;
    private ImageIcon icoGomme;
    private ImageIcon icoSuperGomme;
    
    private ImageIcon icoMur;

    ImageIcon imMur ;
    // Wall image bord
    ImageIcon imMurBordUp ;
    ImageIcon imMurBordDown ;
    ImageIcon imMurBordLeft ;
    ImageIcon imMurBordRight ;
    // Wall image Coin
    ImageIcon imMurCoinUpLeft ;
    ImageIcon imMurCoinUpRight ;
    ImageIcon imMurCoinDownLeft ;
    ImageIcon imMurCoinDownRight ;
    // Wall image Coin Interne
    ImageIcon imCaseInternalCornerUpLeft;
    ImageIcon imCaseInternalCornerUpRight ;
    ImageIcon imCaseInternalCornerDownLeft ;
    ImageIcon imCaseInternalCornerDownRight;
    // Wall image 1 case plein
    ImageIcon im1CasePleinHorizontal ;
    ImageIcon im1CasePleinVertical ;
    ImageIcon imCoin1CaseUpLeft ;
    ImageIcon imCoin1CaseUpRight ;
    ImageIcon imCoin1CaseDownLeft ;
    ImageIcon imCoin1CaseDownRight ;
    ImageIcon Case1ReversPleinLeft ;
    ImageIcon Case1ReversPleinRight ;

    private JLabel[][] tabJLabel; // cases graphique (au moment du rafraichissement, chaque case va être associé à une icône, suivant ce qui est présent dans la partie modèle)


    public VueControleurPacMan(int _sizeX, int _sizeY) {

        sizeX = _sizeX;
        sizeY = _sizeY;

        chargerLesIcones();
        placerLesComposantsGraphiques();

        ajouterEcouteurClavier();

    }

    private void ajouterEcouteurClavier() {

        addKeyListener(new KeyAdapter() { // new KeyAdapter() { ... } est une instance de classe anonyme, il s'agit d'un objet qui correspond au controleur dans MVC
            @Override
            public void keyPressed(KeyEvent e) {
                
                switch(e.getKeyCode()) {  // on écoute les flèches de direction du clavier
                    case KeyEvent.VK_LEFT : jeu.getPacman().setDirection(Direction.gauche); break;
                    case KeyEvent.VK_RIGHT : jeu.getPacman().setDirection(Direction.droite); break;
                    case KeyEvent.VK_DOWN : jeu.getPacman().setDirection(Direction.bas); break;
                    case KeyEvent.VK_UP : jeu.getPacman().setDirection(Direction.haut); break;
                }
                
            }

        });

    }

    public void setJeu(Jeu _jeu) {
        jeu = _jeu;
    }

    private void chargerLesIcones() {
        icoPacMan = chargerIcone("Images/Pacman.png");
        icoCouloir = chargerIcone("Images/ressource/Vide.png");
        icoFantome = chargerIcone("Images/Fantome.png");
        icoFantomeMort = chargerIcone("Images/ressource/DEADGHOST1.png");
        //icoMur = chargerIcone("Images/Mur.png");
        icoGomme = chargerIcone("Images/ressource/Gomme.png");
        icoSuperGomme = chargerIcone("Images/ressource/superGomme.png");
        
        
        
        imMur = chargerIcone("Images/ressource/wall/MurPlein.png");
    // Wall image bord
        imMurBordUp = chargerIcone("Images/ressource/wall/BordUp.png");
        imMurBordDown = chargerIcone("Images/ressource/wall/BordDown.png");
        imMurBordLeft = chargerIcone("Images/ressource/wall/BordLeft.png");
        imMurBordRight = chargerIcone("Images/ressource/wall/BordRight.png");
       // Wall image Coin
        imMurCoinUpLeft = chargerIcone("Images/ressource/wall/CoinUpLeft.png");
        imMurCoinUpRight = chargerIcone("Images/ressource/wall/CoinUpRight.png");
        imMurCoinDownLeft = chargerIcone("Images/ressource/wall/CoinDownLeft.png");
        imMurCoinDownRight = chargerIcone("Images/ressource/wall/CoinDownRight.png");
       // Wall image Coin Interne
        imCaseInternalCornerUpLeft = chargerIcone("Images/ressource/wall/CaseInternalCornerUpLeft.png");
        imCaseInternalCornerUpRight = chargerIcone("Images/ressource/wall/CaseInternalCornerUpRight.png");
        imCaseInternalCornerDownLeft = chargerIcone("Images/ressource/wall/CaseInternalCornerDownLeft.png");
        imCaseInternalCornerDownRight = chargerIcone("Images/ressource/wall/CaseInternalCornerDownRight.png");
       // Wall image 1 case plein
        im1CasePleinHorizontal = chargerIcone("Images/ressource/wall/Plein1CaseHorizontal.png");
        im1CasePleinVertical = chargerIcone("Images/ressource/wall/Plein1CaseVertical.png");
        imCoin1CaseUpLeft = chargerIcone("Images/ressource/wall/Coin1CaseUpLeft.png");
        imCoin1CaseUpRight = chargerIcone("Images/ressource/wall/Coin1CaseUpRight.png");
        imCoin1CaseDownLeft = chargerIcone("Images/ressource/wall/Coin1CaseDownLeft.png");
        imCoin1CaseDownRight = chargerIcone("Images/ressource/wall/Coin1CaseDownRight.png");
        Case1ReversPleinLeft = chargerIcone("Images/ressource/wall/Case1ReversPleinLeft.png");
        Case1ReversPleinRight = chargerIcone("Images/ressource/wall/Case1ReversPleinRight.png"); 
        
    }

    private ImageIcon chargerIcone(String urlIcone) {

        BufferedImage image = null;
        try {
            image = ImageIO.read(new File(urlIcone));
        } catch (IOException ex) {
            Logger.getLogger(VueControleurPacMan.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return new ImageIcon(image);
    }

    private void placerLesComposantsGraphiques() {

        setTitle("PacMan");
        setSize(1000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // permet de terminer l'application à la fermeture de la fenêtre

        JComponent grilleJLabels = new JPanel(new GridLayout(this.sizeX, this.sizeY)); // grilleJLabels va contenir les cases graphiques et les positionner sous la forme d'une grille

        tabJLabel = new JLabel[sizeY][sizeX];
        

        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {

                JLabel jlab = new JLabel();
                tabJLabel[y][x] = jlab; // on conserve les cases graphiques dans tabJLabel pour avoir un accès pratique à celles-ci (voir mettreAJourAffichage() )
                grilleJLabels.add(jlab);
                
            }

        }

        add(grilleJLabels);

    }

    
    /**
     * Il y a une grille du côté du modèle ( jeu.getGrille() ) et une grille du côté de la vue (tabJLabel)
     */
    private void mettreAJourAffichage() {

        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                if (jeu.getGrille()[x][y] instanceof Pacman) { // si la grille du modèle contient un Pacman, on associe l'icône Pacman du côté de la vue
                    
                    tabJLabel[x][y].setIcon(icoPacMan);
                    
                } else if (jeu.getGrille()[x][y] instanceof Fantome) {
                    Entite f = (Entite)jeu.getGrille()[x][y];
                    if(f.getPeutManger()){
                        tabJLabel[x][y].setIcon(icoFantome);
                    }else{
                        tabJLabel[x][y].setIcon(icoFantomeMort);
                    }
                }else if (jeu.getGrille()[x][y] instanceof CaseGomme){
                    
                    tabJLabel[x][y].setIcon(icoGomme);
                }else if (jeu.getGrille()[x][y] instanceof CaseSuperGomme){
                    
                    tabJLabel[x][y].setIcon(icoSuperGomme);
                } else if (jeu.getGrille()[x][y] instanceof CaseMur){
                    
                    tabJLabel[x][y].setIcon(imMur);
                }else {
                    
                        tabJLabel[x][y].setIcon(icoCouloir);
                        
                        
                    
                }
                
             //initialiserAff();  

            }
        }
        
        
        
        

    }

    public void initialiserAff(){
            for (int x = 0; x < sizeX; x++) {
                for (int y = 0; y < sizeY; y++) {
                    if (jeu.getGrille()[x][y] instanceof CaseMur){
                    
                    tabJLabel[x][y].setIcon(imMur);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseMurUp)
                    {
                        tabJLabel[x][y].setIcon(imMurBordUp);
                    }
                    if(jeu.getGrille()[x][y] instanceof CaseMurDown)
                    {
                        tabJLabel[x][y].setIcon(imMurBordDown);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseMurLeft)
                    {
                        tabJLabel[x][y].setIcon(imMurBordLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseMurRight)
                    {
                       tabJLabel[x][y].setIcon(imMurBordRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseCoinUpLeft)
                    {
                        tabJLabel[x][y].setIcon(imMurCoinUpLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseCoinUpRight)
                    {
                        tabJLabel[x][y].setIcon(imMurCoinUpRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseCoinDownLeft)
                    {
                        tabJLabel[x][y].setIcon(imMurCoinDownLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseCoinDownRight)
                    {
                        tabJLabel[x][y].setIcon(imMurCoinDownRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseInternalCornerUpLeft)
                    {
                        tabJLabel[x][y].setIcon(imCaseInternalCornerUpLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseInternalCornerUpRight)
                    {
                        tabJLabel[x][y].setIcon(imCaseInternalCornerUpRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseInternalCornerDownLeft)
                    {
                        tabJLabel[x][y].setIcon(imCaseInternalCornerDownLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof CaseInternalCornerDownRight)
                    {
                        tabJLabel[x][y].setIcon(imCaseInternalCornerDownRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof Case1PleinHorizontal)
                    {
                        tabJLabel[x][y].setIcon(im1CasePleinHorizontal);
                    }
                    if(jeu.getGrille()[x][y] instanceof Case1PleinVertical)
                    {
                        tabJLabel[x][y].setIcon(im1CasePleinVertical);
                    }
                    if(jeu.getGrille()[x][y]  instanceof Coin1CaseUpLeft)
                    {
                        tabJLabel[x][y].setIcon(imCoin1CaseUpLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof Coin1CaseUpRight)
                    {
                        tabJLabel[x][y].setIcon(imCoin1CaseUpRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof Coin1CaseDownLeft)
                    {
                        tabJLabel[x][y].setIcon(imCoin1CaseDownLeft);
                    }
                    if(jeu.getGrille()[x][y]  instanceof Coin1CaseDownRight)
                    {
                        tabJLabel[x][y].setIcon(imCoin1CaseDownRight);
                    }
                    if(jeu.getGrille()[x][y]  instanceof modele.PkgMur.Case1ReversPleinLeft)
                    {
                        tabJLabel[x][y].setIcon(Case1ReversPleinLeft);
                    }
                    if(jeu.getGrille()[x][y] instanceof modele.PkgMur.Case1ReversPleinRight)
                    {
                        tabJLabel[x][y].setIcon(Case1ReversPleinRight);
                    }
                }
            }
        }
    
    @Override
    public void update(Observable o, Object arg) {
        
        
        mettreAJourAffichage();
        //initialiserAff();
        
        /*
        SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        mettreAJourAffichage();
                    }
                }); 
       */
        
    }

}
